﻿using System;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Alife.Framework;
using Alife.Foundation;
using Alife.Function.FunctionCaller;
using Microsoft.Extensions.Logging;
using Microsoft.SemanticKernel.ChatCompletion;

namespace MyQQBot
{
    public class QQBotConfig
    {
        public string AppId { get; set; }
        public string AppSecret { get; set; }

        // 开关：是否开启频道消息、是否开启私聊消息
        public bool EnableGuildMessages { get; set; } = false;   // 默认关闭频道
        public bool EnableDirectMessages { get; set; } = true;   // 默认只开私聊

        // 旧字段，保留兼容，不用填
        public string Token { get; set; }
    }

    [Module("QQ机器人", "接入QQ官方机器人，让AI和QQ用户聊天。", defaultCategory: "咪露的小工具")]
    public class QQBotPlugin : ChatBehaviour, IConfigurable<QQBotConfig>
    {
        private readonly ILogger<QQBotPlugin> _logger;
        private readonly Interactor<QQBotPlugin> _interactor;
        private readonly HttpClient _http = new();
        private ClientWebSocket _ws;
        private CancellationTokenSource _cts;

        // 保存最近一次收到的消息信息（用于回复）
        private string _lastUserOpenId = "";
        private string _lastMsgId = "";
        private string _lastChannelId = "";
        private bool _isPrivate = true;

        private string _accessToken = "";
        private int _lastSeq = 0;           // 最近收到事件的 s 值
        private int _heartbeatInterval = 45000; // 默认心跳间隔，会从 Hello 事件更新

        public QQBotConfig Configuration { get; set; } = null!;

        private readonly XmlFunctionCaller _functionCaller;

        public QQBotPlugin(ILogger<QQBotPlugin> logger, Interactor<QQBotPlugin> interactor, XmlFunctionCaller functionCaller)
        {
            _logger = logger;
            _interactor = interactor;
            _functionCaller = functionCaller;
        }

        // 热重载不会销毁旧实例，所以用进程级槽位记录「当前活跃的连接」和「世代号」，
        // 新实例启动时主动关掉旧连接，旧实例也会因世代号对不上而停止重连。
        private const string WsSlotKey = "MyQQBot.ActiveWebSocket";
        private const string GenSlotKey = "MyQQBot.ConnectionGeneration";
        private int _generation;

        protected override async Task OnAwake()
        {
            // 关掉上一次热重载遗留的连接
            if (AppDomain.CurrentDomain.GetData(WsSlotKey) is WebSocket oldWs)
            {
                try
                {
                    if (oldWs.State == WebSocketState.Open)
                        await oldWs.CloseAsync(WebSocketCloseStatus.NormalClosure, "replaced", CancellationToken.None);
                }
                catch { }
                try { oldWs.Dispose(); } catch { }
            }

            int gen = AppDomain.CurrentDomain.GetData(GenSlotKey) is int v ? v : 0;
            _generation = gen + 1;
            AppDomain.CurrentDomain.SetData(GenSlotKey, _generation);
            _logger.LogInformation($"QQBot 世代号: {_generation}");

            XmlHandler handler = new(this)
            {
                Description = "QQ 消息发送。把内容通过 QQ 官方机器人发送出去。",
                Explanation = "只有在 QQ 消息被触发时才能发送，内容需用标签包裹。"
            };
            _functionCaller.RegisterHandler(handler, DocumentMode.Explicit,
                cancellationToken: DestroyCancellationToken);

            _ = Task.Run(() => ConnectAndReceiveAsync(), DestroyCancellationToken);
        }

        private bool _isDestroyed;

        protected override async Task OnDestroy()
        {
            _isDestroyed = true;
            if (_cts != null)
            {
                _cts.Cancel();
                _cts.Dispose();
            }
            if (_ws != null && _ws.State == WebSocketState.Open)
            {
                await _ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "plugin destroy", CancellationToken.None);
            }
            _ws?.Dispose();
            await base.OnDestroy();
        }

        // ============ 1. 获取 Access Token ============
        private async Task<string> GetAccessTokenAsync()
        {
            string appId = Configuration.AppId;
            string appSecret = Configuration.AppSecret;

            var payload = new { appId = appId, clientSecret = appSecret };
            var request = new HttpRequestMessage(HttpMethod.Post,
                "https://bots.qq.com/app/getAppAccessToken");
            request.Content = new StringContent(
                JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

            var response = await _http.SendAsync(request);
            string responseBody = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"获取AccessToken失败: {response.StatusCode}, 响应: {responseBody}");
            }

            using var doc = JsonDocument.Parse(responseBody);
            string token = doc.RootElement.GetProperty("access_token").GetString();
            if (string.IsNullOrEmpty(token))
                throw new Exception("AccessToken为空");

            return token;
        }

        // ============ 2. WebSocket 连接与接收 ============
        private bool IsCurrentGeneration()
        {
            int cur = AppDomain.CurrentDomain.GetData(GenSlotKey) is int v ? v : 0;
            return _generation == cur;
        }

        private async Task ConnectAndReceiveAsync()
        {
            try
            {
                if (!IsCurrentGeneration())
                    return;

                _accessToken = await GetAccessTokenAsync();
                _logger.LogInformation("获取AccessToken成功");

                if (!IsCurrentGeneration())
                    return;

                _ws = new ClientWebSocket();
                await _ws.ConnectAsync(new Uri("wss://api.bot.qq.com/websocket"), DestroyCancellationToken);
                _logger.LogInformation("QQ WebSocket已连接");

                AppDomain.CurrentDomain.SetData(WsSlotKey, _ws);

                _cts = new CancellationTokenSource();

                await SendIdentifyAsync();
                _logger.LogInformation("已发送鉴权信息");

                // 启动心跳任务，使用动态间隔
                _ = Task.Run(() => HeartbeatLoopAsync(_cts.Token));

                await ReceiveLoopAsync(_cts.Token);
            }
            catch (Exception ex)
            {
                if (_isDestroyed || DestroyCancellationToken.IsCancellationRequested)
                    return;
                _logger.LogError(ex, "QQ WebSocket连接或接收出错，10秒后重连...");
                try
                {
                    await Task.Delay(10000, DestroyCancellationToken);
                }
                catch (OperationCanceledException)
                {
                    return;
                }
                if (_isDestroyed || DestroyCancellationToken.IsCancellationRequested || !IsCurrentGeneration())
                    return;
                _ = Task.Run(() => ConnectAndReceiveAsync(), DestroyCancellationToken);
            }
        }

        private async Task SendIdentifyAsync()
        {
            int intents = 0;

            if (Configuration.EnableGuildMessages)
                intents |= 1 << 9;   // 频道消息

            if (Configuration.EnableDirectMessages)
                intents |= 1 << 25;  // 单聊消息事件

            _logger.LogInformation($"当前 intents 值: {intents}");

            var payload = new
            {
                op = 2,
                d = new
                {
                    token = $"QQBot {_accessToken}",
                    intents = intents,
                    shard = new[] { 0, 1 },
                    properties = new
                    {
                        os = "windows",
                        browser = "my_library",
                        device = "my_library"
                    }
                }
            };
            string json = JsonSerializer.Serialize(payload);
            byte[] bytes = Encoding.UTF8.GetBytes(json);
            await _ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
        }

        private async Task HeartbeatLoopAsync(CancellationToken ct)
        {
            try
            {
                while (!ct.IsCancellationRequested)
                {
                    await Task.Delay(_heartbeatInterval, ct);
                    if (_ws.State != WebSocketState.Open) break;

                    // 心跳包 d 传最近收到的 s，如果还没收到事件则传 null
                    var payload = new
                    {
                        op = 1,
                        d = _lastSeq == 0 ? (int?)null : _lastSeq
                    };
                    string json = JsonSerializer.Serialize(payload);
                    byte[] bytes = Encoding.UTF8.GetBytes(json);
                    await _ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, ct);
                }
            }
            catch (OperationCanceledException) { }
            catch (Exception ex)
            {
                _logger.LogError(ex, "心跳发送失败");
            }
        }

        private async Task ReceiveLoopAsync(CancellationToken ct)
        {
            var buffer = new byte[8192];
            var messageStream = new MemoryStream();

            while (!ct.IsCancellationRequested && _ws.State == WebSocketState.Open)
            {
                WebSocketReceiveResult result;
                do
                {
                    result = await _ws.ReceiveAsync(new ArraySegment<byte>(buffer), ct);
                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        _logger.LogWarning($"服务器关闭连接: {_ws.CloseStatus} {_ws.CloseStatusDescription}");
                        await _ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "server close", ct);
                        throw new Exception("服务器关闭连接"); // 触发重连
                    }
                    messageStream.Write(buffer, 0, result.Count);
                } while (!result.EndOfMessage);

                string json = Encoding.UTF8.GetString(messageStream.ToArray());
                messageStream.SetLength(0);
                await ProcessWebSocketMessageAsync(json);
            }
        }

        private async Task ProcessWebSocketMessageAsync(string raw)
        {
            // 热重载遗留的旧连接即使还连着，也不再处理消息，避免重复推送
            if (!IsCurrentGeneration())
                return;

            using var doc = JsonDocument.Parse(raw);
            var root = doc.RootElement;
            int op = root.GetProperty("op").GetInt32();

            // 更新 seq（如果存在）
            if (root.TryGetProperty("s", out var sProp))
            {
                _lastSeq = sProp.GetInt32();
            }

            // 打印所有事件（心跳 ACK 不打印）
            if (op != 11)
            {
                _logger.LogInformation($"收到WS消息: op={op}, type={(op == 0 ? root.GetProperty("t").GetString() : "-")}");
            }

            if (op == 10)
            {
                // 读取心跳间隔
                if (root.TryGetProperty("d", out var d) && d.TryGetProperty("heartbeat_interval", out var interval))
                {
                    _heartbeatInterval = interval.GetInt32();
                    _logger.LogInformation($"收到Hello事件，心跳间隔={_heartbeatInterval}ms");
                }
                else
                {
                    _logger.LogInformation("收到Hello事件");
                }
            }
            else if (op == 7)
            {
                // 服务器要求重连
                _logger.LogInformation("收到重连请求 (op=7)，准备重连...");
                if (_ws != null && _ws.State == WebSocketState.Open)
                {
                    await _ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "server request reconnect", CancellationToken.None);
                }
                throw new Exception("服务器要求重连"); // 触发外层重连
            }
            else if (op == 0)
            {
                string type = root.GetProperty("t").GetString();

                if (type == "C2C_MESSAGE_CREATE")
                {
                    var d = root.GetProperty("d");
                    string content = d.GetProperty("content").GetString();
                    string msgId = d.GetProperty("id").GetString();

                    string userOpenId = "";
                    if (d.TryGetProperty("author", out var author) && author.TryGetProperty("user_openid", out var auo))
                        userOpenId = auo.GetString();

                    if (string.IsNullOrEmpty(userOpenId))
                    {
                        _logger.LogWarning("单聊消息中未找到 user_openid");
                        return;
                    }

                    _isPrivate = true;
                    _lastUserOpenId = userOpenId;
                    _lastMsgId = msgId;

                    _logger.LogInformation($"收到私聊消息: user_openid={userOpenId}, content={content}");
                    _interactor.Poke($"用户通过QQ说：{content}\n（这是QQ消息，请用QQChat标签回复）");
                }
                else if (type == "MESSAGE_CREATE")
                {
                    var d = root.GetProperty("d");
                    string content = d.GetProperty("content").GetString();
                    string channelId = d.GetProperty("channel_id").GetString();
                    string msgId = d.GetProperty("id").GetString();

                    _isPrivate = false;
                    _lastChannelId = channelId;
                    _lastMsgId = msgId;

                    _logger.LogInformation($"收到频道消息: channel_id={channelId}, content={content}");
                    _interactor.Poke($"用户通过QQ频道说：{content}\n（这是QQ频道消息，请用QQChat标签回复）");
                }
            }
        }

        // ============ 3. 发送入口：AI 用 QQChat 标签调用 ============
        [XmlFunction(FunctionMode.Content, "QQChat")]
        [Description("把内容通过 QQ 官方机器人发送出去（仅在 QQ 消息触发的对话中可用）")]
        public async Task QQChat(XmlExecutorContext context, CancellationToken cancellationToken = default)
        {
            if (context.CallMode != CallMode.Content)
                return;

            string reply = context.Content.Trim();
            if (string.IsNullOrWhiteSpace(reply)) return;

            if (_isPrivate)
            {
                if (!string.IsNullOrEmpty(_lastUserOpenId))
                    await SendPrivateMessageAsync(_lastUserOpenId, _lastMsgId, reply);
            }
            else
            {
                if (!string.IsNullOrEmpty(_lastChannelId))
                    await SendChannelMessageAsync(_lastChannelId, reply);
            }
        }

        // ============ 4. 发送消息 ============
        private async Task SendPrivateMessageAsync(string userOpenId, string replyMsgId, string content)
        {
            var payload = new
            {
                content = content,
                msg_type = 0,
                msg_id = replyMsgId
            };

            var request = new HttpRequestMessage(HttpMethod.Post,
                $"https://api.bot.qq.com/v2/users/{userOpenId}/messages");
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("QQBot", _accessToken);
            request.Content = new StringContent(
                JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

            var response = await _http.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                string error = await response.Content.ReadAsStringAsync();
                _logger.LogWarning($"发送私聊消息失败: {response.StatusCode}, 错误: {error}");
            }
            else
            {
                _logger.LogInformation("私聊回复已发送");
            }
        }

        private async Task SendChannelMessageAsync(string channelId, string content)
        {
            var payload = new { content = content, msg_type = 0 };
            var request = new HttpRequestMessage(HttpMethod.Post,
                $"https://api.bot.qq.com/v2/channels/{channelId}/messages");
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("QQBot", _accessToken);
            request.Content = new StringContent(
                JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

            var response = await _http.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                string error = await response.Content.ReadAsStringAsync();
                _logger.LogWarning($"发送频道消息失败: {response.StatusCode}, 错误: {error}");
            }
        }
        // 去掉 AI 回复里的功能标签和注释，QQ 里只显示纯文字
        private static string StripXmlTags(string text)
        {
            if (string.IsNullOrEmpty(text)) return "";
            string result = System.Text.RegularExpressions.Regex.Replace(
                text, "<!--.*?-->", "", System.Text.RegularExpressions.RegexOptions.Singleline);
            result = System.Text.RegularExpressions.Regex.Replace(result, "<[^>]*>", "");
            return result.Trim();
        }

    }

}

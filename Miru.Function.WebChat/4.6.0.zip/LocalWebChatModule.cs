using System;
using System.ComponentModel;
using System.Threading;
using System.Threading.Tasks;
using Alife.Framework;
using Alife.Function.FunctionCaller;
using Microsoft.Extensions.Logging;

namespace Miru.Function.WebChat;

/// <summary>
/// 局域网 WebChat 的配置。
/// </summary>
public class LocalWebChatConfig
{
    [DisplayName("监听端口")]
    [Description("WebChat 网页服务的端口，局域网设备通过此端口访问。")]
    public int Port { get; set; } = 14763;
}

/// <summary>
/// 局域网 WebChat 模块。
/// 职责：
/// 1. 启动/停止本地网页服务；
/// 2. 把网页发来的消息转达给 AI；
/// 3. 把 AI 用 &lt;WebChat&gt; 标签发出的内容广播到所有网页。
/// 网络细节交给 LocalWebChatServer，消息格式交给 WebChatMessages。
/// </summary>
[Module(
    "局域网 WebChat",
    "在局域网内提供网页聊天界面。AI 可用 &lt;WebChat&gt;消息&lt;/WebChat&gt; 把内容发送到所有设备。",
    defaultCategory: "咪露的小工具")]
public class LocalWebChatModule(
    XmlFunctionCaller functionCaller,
    PluginSystem pluginSystem,
    Interactor<LocalWebChatModule> interactor,
    ILogger<LocalWebChatModule> logger) :
    ChatBehaviour,
    IConfigurable<LocalWebChatConfig>
{
    public LocalWebChatConfig Configuration { get; set; } = null!;

    LocalWebChatServer? server;

    protected override async Task OnAwake()
    {
        int port = Configuration.Port;

        // 网页文件放在插件目录下的 wwwroot。
        string pluginDirectory = pluginSystem.PluginContext.GetPluginDirectoryPath("Miru.Function.WebChat");
        string webRoot = System.IO.Path.Combine(pluginDirectory, "wwwroot");

        server = new LocalWebChatServer(port, webRoot, logger);
        server.TextReceived += OnClientTextAsync;

        try
        {
            await server.StartAsync(DestroyCancellationToken);
        }
        catch (Exception e)
        {
            logger.LogError($"WebChat 服务启动失败，端口 {port}。请检查端口是否被占用。\n{e}");
            throw;
        }

        string address = $"http://{LocalWebChatServer.GetLocalIP()}:{port}";
        logger.LogInformation($"WebChat 服务已启动，局域网地址：{address}");

        XmlHandler handler = new(this)
        {
            Description = "局域网 WebChat 服务。把内容通过网页发送到局域网内的所有设备。",
            Explanation = "在需要把消息展示到手机等局域网设备时使用此标签。"
        };
        functionCaller.RegisterHandler(handler, DocumentMode.Explicit,
            cancellationToken: DestroyCancellationToken);
    }

    protected override async Task OnDestroy()
    {
        if (server != null)
        {
            server.TextReceived -= OnClientTextAsync;
            await server.DisposeAsync();
            server = null;
        }
    }

    /// <summary>
    /// 网页端发来一段文本时调用。把内容转达给 AI。
    /// </summary>
    public Task UserMessage([Description("用户输入的消息内容")] string message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return Task.CompletedTask;

        interactor.Poke($"用户通过网页说：{message}\n（网页消息请用WebChat标签回复）");
        return Task.CompletedTask;
    }

    /// <summary>
    /// AI 通过 &lt;WebChat&gt;消息&lt;/WebChat&gt; 调用，把内容广播到所有网页设备。
    /// </summary>
    [XmlFunction(FunctionMode.Content, "WebChat")]
    [Description("把消息广播到局域网 WebChat 所有设备上显示")]
    public async Task WebChat(XmlExecutorContext context, CancellationToken cancellationToken = default)
    {
        if (context.CallMode != CallMode.Content)
            return;

        string content = context.Content.Trim();
        if (string.IsNullOrWhiteSpace(content))
            return;

        await BroadcastTextAsync(content, cancellationToken);
    }

    async Task OnClientTextAsync(string clientId, string raw)
    {
        if (server == null)
            return;

        ClientMessage? message;
        try
        {
            message = WebChatProtocol.DeserializeClientMessage(raw);
        }
        catch (Exception e)
        {
            logger.LogWarning($"解析网页消息失败：{e.Message}");
            return;
        }

        if (message == null)
            return;

        switch (message.Type)
        {
            case WebChatProtocol.TypePing:
                await server.BroadcastRawAsync(
                    WebChatProtocol.SerializePong(),
                    DestroyCancellationToken);
                break;

            case WebChatProtocol.TypeChat:
            case null:
                await UserMessage(message.Text ?? "");
                break;

            default:
                logger.LogWarning($"收到未知类型的网页消息：{message.Type}");
                break;
        }
    }

    /// <summary>把一段 AI 文本广播到所有网页设备。</summary>
    public Task BroadcastTextAsync(string text, CancellationToken cancellationToken = default)
    {
        if (server == null)
            return Task.CompletedTask;

        return server.BroadcastAsync(new ServerMessage
        {
            Type = WebChatProtocol.TypeMessage,
            Role = "assistant",
            Text = text,
            Time = DateTimeOffset.Now.ToUnixTimeMilliseconds()
        }, cancellationToken);
    }
}

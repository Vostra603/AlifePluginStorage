// 本地存储：手机端刷新、重连后聊天记录不丢失，可手动清空。
const ChatStorage = (function () {
    const USERS_KEY = 'webchat.users';
    const MESSAGES_KEY = 'webchat.messages';
    const SETTINGS_KEY = 'webchat.settings';
    const MAX_MESSAGES = 500;

    function read(key, fallback) {
        try {
            const raw = localStorage.getItem(key);
            return raw ? JSON.parse(raw) : fallback;
        } catch (e) {
            return fallback;
        }
    }

    function write(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (e) {
            // 存储写满或被禁用时静默失败，不影响聊天
        }
    }

    // ---- 客户端标识 ----
    function getClientId() {
        let id = read(USERS_KEY, null);
        if (!id) {
            id = 'c-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
            write(USERS_KEY, id);
        }
        return id;
    }

    // ---- 聊天记录 ----
    function getMessages() {
        return read(MESSAGES_KEY, []);
    }

    function addMessage(message) {
        const list = getMessages();
        list.push(message);
        while (list.length > MAX_MESSAGES) {
            list.shift();
        }
        write(MESSAGES_KEY, list);
    }

    function clearMessages() {
        write(MESSAGES_KEY, []);
    }

    // ---- 界面设置 ----
    function getSettings() {
        return read(SETTINGS_KEY, { fontSize: 16 });
    }

    function saveSettings(settings) {
        write(SETTINGS_KEY, settings);
    }

    return {
        getClientId,
        getMessages,
        addMessage,
        clearMessages,
        getSettings,
        saveSettings
    };
})();

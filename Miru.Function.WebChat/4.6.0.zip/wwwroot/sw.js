// 离线缓存：让添加到主屏的应用打开更快，断网也能显示界面。
const CACHE_NAME = 'webchat-v2';
const ASSETS = [
    './',
    './index.html',
    './style.css',
    './storage.js',
    './connection.js',
    './app.js',
    './manifest.webmanifest',
    './icon-192.png',
    './icon-512.png',
    './apple-touch-icon.png'
];

self.addEventListener('install', function (event) {
    event.waitUntil(
        caches.open(CACHE_NAME).then(function (cache) {
            return cache.addAll(ASSETS);
        }).then(function () {
            return self.skipWaiting();
        })
    );
});

self.addEventListener('activate', function (event) {
    event.waitUntil(
        caches.keys().then(function (keys) {
            return Promise.all(keys.map(function (key) {
                if (key !== CACHE_NAME) {
                    return caches.delete(key);
                }
            }));
        }).then(function () {
            return self.clients.claim();
        })
    );
});

self.addEventListener('fetch', function (event) {
    const url = new URL(event.request.url);

    // 只缓存同源静态资源，WebSocket 与其它请求不经过缓存。
    if (url.origin !== location.origin || event.request.method !== 'GET') {
        return;
    }

    // 网络优先：优先拿最新代码，断网时才回退到缓存，避免旧缓存卡住新版本。
    event.respondWith(
        fetch(event.request).then(function (response) {
            if (response && response.status === 200) {
                const copy = response.clone();
                caches.open(CACHE_NAME).then(function (cache) {
                    cache.put(event.request, copy);
                });
            }
            return response;
        }).catch(function () {
            return caches.match(event.request);
        })
    );
});

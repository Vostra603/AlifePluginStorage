// 与服务端的 WebSocket 连接：自动重连 + 心跳 + 心跳超时判断。
const ChatConnection = (function () {
    const PING_INTERVAL = 20000; // 每 20 秒发一次心跳
    const PONG_TIMEOUT = 8000;   // 8 秒内没等到回话就认为断开

    let socket = null;
    let heartbeatTimer = null;
    let reconnectTimer = null;
    let pongTimer = null;
    let closedByUser = false;

    const handlers = {
        onOpen: null,
        onClose: null,
        onMessage: null,
        onStatusChange: null
    };

    function notifyStatus(status) {
        if (handlers.onStatusChange) {
            handlers.onStatusChange(status);
        }
    }

    function clearTimers() {
        if (heartbeatTimer) { clearInterval(heartbeatTimer); heartbeatTimer = null; }
        if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
        if (pongTimer) { clearTimeout(pongTimer); pongTimer = null; }
    }

    function clearPongTimer() {
        if (pongTimer) { clearTimeout(pongTimer); pongTimer = null; }
    }

    // 发出心跳并开始等待回应，超时则判定连接已死。
    function sendPingAndWait() {
        if (!socket || socket.readyState !== WebSocket.OPEN) return;

        socket.send(JSON.stringify({ type: 'ping', clientId: ChatStorage.getClientId() }));

        clearPongTimer();
        pongTimer = setTimeout(function () {
            pongTimer = null;
            // 没等到回应，认为连接已断，主动关闭以触发重连。
            notifyStatus('disconnected');
            try {
                if (socket) socket.close();
            } catch (e) { }
        }, PONG_TIMEOUT);
    }

    function startHeartbeat() {
        heartbeatTimer = setInterval(sendPingAndWait, PING_INTERVAL);
    }

    function scheduleReconnect() {
        if (closedByUser) return;
        if (reconnectTimer) return;
        reconnectTimer = setTimeout(function () {
            reconnectTimer = null;
            connect();
        }, 2000);
    }

    function connect() {
        closedByUser = false;
        clearTimers();

        notifyStatus('connecting');

        const protocol = location.protocol === 'https:' ? 'wss://' : 'ws://';
        socket = new WebSocket(protocol + location.host);

        socket.onopen = function () {
            notifyStatus('connected');
            startHeartbeat();
            if (handlers.onOpen) handlers.onOpen();
        };

        socket.onclose = function () {
            notifyStatus('disconnected');
            clearTimers();
            if (handlers.onClose) handlers.onClose();
            scheduleReconnect();
        };

        socket.onerror = function () {
            notifyStatus('disconnected');
        };

        socket.onmessage = function (event) {
            let data = null;
            try {
                data = JSON.parse(event.data);
            } catch (e) {
                data = { type: 'message', role: 'assistant', text: event.data };
            }

            // 收到心跳回应，清除超时等待。
            if (data && data.type === 'pong') {
                clearPongTimer();
                return;
            }

            if (handlers.onMessage) handlers.onMessage(data);
        };
    }

    // 立刻检查连接是否还活着（页面回到前台时使用）。
    function probe() {
        if (!socket || socket.readyState !== WebSocket.OPEN) {
            connect();
            return;
        }
        sendPingAndWait();
    }

    function send(text) {
        if (!socket || socket.readyState !== WebSocket.OPEN) {
            return false;
        }
        socket.send(JSON.stringify({
            type: 'chat',
            text: text,
            clientId: ChatStorage.getClientId()
        }));
        return true;
    }

    function disconnect() {
        closedByUser = true;
        clearTimers();
        if (socket) {
            socket.close();
            socket = null;
        }
    }

    function on(name, callback) {
        if (name in handlers) {
            handlers[name] = callback;
        }
    }

    return {
        connect,
        disconnect,
        probe,
        send,
        on,
        isOpen: function () {
            return !!socket && socket.readyState === WebSocket.OPEN;
        }
    };
})();

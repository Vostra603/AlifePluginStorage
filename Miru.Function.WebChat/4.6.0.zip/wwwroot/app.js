// 界面主逻辑：渲染、输入、字体、清空。
(function () {
    const messagesEl = document.getElementById('messages');
    const inputEl = document.getElementById('input');
    const sendBtn = document.getElementById('send-btn');
    const connStatusEl = document.getElementById('conn-status');
    const connTextEl = document.getElementById('conn-text');
    const fontSlider = document.getElementById('font-size');
    const root = document.documentElement;

    // ---- 字体大小 ----
    const settings = ChatStorage.getSettings();
    applyFontSize(settings.fontSize || 16);

    fontSlider.addEventListener('input', function (e) {
        applyFontSize(parseInt(e.target.value, 10));
    });
    document.getElementById('font-inc').addEventListener('click', function () {
        fontSlider.value = Math.min(24, parseInt(fontSlider.value, 10) + 1);
        fontSlider.dispatchEvent(new Event('input'));
    });
    document.getElementById('font-dec').addEventListener('click', function () {
        fontSlider.value = Math.max(12, parseInt(fontSlider.value, 10) - 1);
        fontSlider.dispatchEvent(new Event('input'));
    });

    function applyFontSize(size) {
        if (isNaN(size)) size = 16;
        root.style.setProperty('--font-size', size + 'px');
        fontSlider.value = size;
        const s = ChatStorage.getSettings();
        s.fontSize = size;
        ChatStorage.saveSettings(s);
    }

    // ---- 渲染 ----
    function formatTime(time) {
        if (!time) return '';
        const d = new Date(time);
        const hh = String(d.getHours()).padStart(2, '0');
        const mm = String(d.getMinutes()).padStart(2, '0');
        return hh + ':' + mm;
    }

    function renderMessage(message, scroll) {
        const div = document.createElement('div');
        const isSelf = message.role === 'user';
        div.className = 'message ' + (isSelf ? 'self' : 'other');

        if (!isSelf) {
            const sender = document.createElement('div');
            sender.className = 'sender';
            sender.textContent = 'AI';
            div.appendChild(sender);
        }

        const bubble = document.createElement('div');
        bubble.className = 'bubble';
        bubble.textContent = message.text;
        div.appendChild(bubble);

        if (message.time) {
            const time = document.createElement('div');
            time.className = 'time';
            time.textContent = formatTime(message.time);
            div.appendChild(time);
        }

        messagesEl.appendChild(div);

        if (scroll !== false) {
            messagesEl.scrollTop = messagesEl.scrollHeight;
        }
    }

    function renderAll() {
        messagesEl.innerHTML = '';
        const list = ChatStorage.getMessages();
        list.forEach(function (m) { renderMessage(m, false); });
        messagesEl.scrollTop = messagesEl.scrollHeight;
    }

    // ---- 发送 ----
    function send() {
        const text = inputEl.value.trim();
        if (!text) return;

        const message = { role: 'user', text: text, time: Date.now() };
        ChatStorage.addMessage(message);
        renderMessage(message);

        const ok = ChatConnection.send(text);
        if (!ok) {
            // 没连上时也保留记录，等重连后可再发
            const tip = { role: 'assistant', text: '（当前未连接到服务端，消息未送达）', time: Date.now() };
            ChatStorage.addMessage(tip);
            renderMessage(tip);
        }

        inputEl.value = '';
    }

    sendBtn.addEventListener('click', send);
    inputEl.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') send();
    });

    // ---- 清空 ----
    document.getElementById('clear-btn').addEventListener('click', function () {
        if (!confirm('确定清空全部聊天记录吗？')) return;
        ChatStorage.clearMessages();
        renderAll();
    });

    // ---- 重联 ----
    document.getElementById('reconnect-btn').addEventListener('click', function () {
        ChatConnection.disconnect();
        ChatConnection.connect();
    });

    // ---- 连接状态 ----
    ChatConnection.on('onStatusChange', function (status) {
        connStatusEl.classList.remove('connected', 'disconnected');
        if (status === 'connected') {
            connStatusEl.classList.add('connected');
            connTextEl.textContent = '已连接';
        } else if (status === 'connecting') {
            connTextEl.textContent = '连接中';
        } else {
            connStatusEl.classList.add('disconnected');
            connTextEl.textContent = '未连接';
        }
    });

    ChatConnection.on('onMessage', function (data) {
        if (!data || data.type !== 'message') return;
        const message = {
            role: data.role || 'assistant',
            text: data.text || '',
            time: data.time || Date.now()
        };
        ChatStorage.addMessage(message);
        renderMessage(message);
    });

    // ---- 启动 ----
    renderAll();
    ChatConnection.connect();

    // 页面切回前台时检查连接是否还活着，断了就重连、没断就发心跳确认。
    document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') {
            ChatConnection.probe();
        }
    });
    // ---- 注册离线缓存（PWA）----
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function () {
            navigator.serviceWorker.register('sw.js').catch(function () {});
        });
    }
})();

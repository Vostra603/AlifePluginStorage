using System.Text;
using System.Text.Json;

namespace Miru.Function.WebChat;

/// <summary>
/// 网页与服务端之间的通信协议。
/// 集中管理消息类型与序列化方式，方便以后扩展（图片、表情、指令等）。
/// </summary>
public static class WebChatProtocol
{
    /// <summary>网页发来的聊天消息。</summary>
    public const string TypeChat = "chat";

    /// <summary>网页发来的心跳。</summary>
    public const string TypePing = "ping";

    /// <summary>服务端下发的聊天消息。</summary>
    public const string TypeMessage = "message";

    /// <summary>服务端下发的心跳回应。</summary>
    public const string TypePong = "pong";

    static readonly JsonSerializerOptions Options = new()
    {
        DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
    };

    public static ClientMessage? DeserializeClientMessage(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
            return null;

        return JsonSerializer.Deserialize<ClientMessage>(raw, Options);
    }

    public static string Serialize(ServerMessage message)
    {
        return JsonSerializer.Serialize(message, Options);
    }

    public static string SerializePong()
    {
        return Serialize(new ServerMessage { Type = TypePong });
    }
}

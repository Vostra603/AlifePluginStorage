using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Logging;

namespace Miru.Function.WebChat;

/// <summary>
/// 局域网 WebChat 服务器。
/// 只负责：启动 Kestrel、托管网页静态文件、管理 WebSocket 连接、收发原始文本。
/// 不包含任何聊天业务逻辑，便于独立修改与扩展。
/// </summary>
public sealed class LocalWebChatServer : IAsyncDisposable
{
    /// <summary>收到某个客户端发来的文本时触发。参数为 (客户端标识, 文本)。</summary>
    public event Func<string, string, Task>? TextReceived;

    /// <summary>客户端连接建立时触发，参数为客户端标识。</summary>
    public event Func<string, Task>? ClientConnected;

    /// <summary>客户端断开时触发，参数为客户端标识。</summary>
    public event Func<string, Task>? ClientDisconnected;

    readonly int port;
    readonly string webRootPath;
    readonly ILogger logger;

    readonly ConcurrentDictionary<string, WebSocket> clients = new();

    IWebHost? host;

    public LocalWebChatServer(int port, string webRootPath, ILogger logger)
    {
        this.port = port;
        this.webRootPath = webRootPath;
        this.logger = logger;
    }

    /// <summary>当前在线客户端数量。</summary>
    public int ClientCount => clients.Count;

    public async Task StartAsync(CancellationToken cancellationToken = default)
    {
        if (host != null)
            throw new InvalidOperationException("服务器已经启动。");

        var newHost = new WebHostBuilder()
            .UseKestrel()
            .UseUrls($"http://0.0.0.0:{port}")
            .Configure(app =>
            {
                app.UseWebSockets(new WebSocketOptions
                {
                    KeepAliveInterval = TimeSpan.FromSeconds(30)
                });

                // 先处理 WebSocket 连接，避免被静态文件中间件拦截。
                app.Use(async (httpContext, next) =>
                {
                    if (httpContext.WebSockets.IsWebSocketRequest)
                    {
                        await HandleWebSocketAsync(httpContext);
                        return;
                    }

                    await next();
                });

                if (Directory.Exists(webRootPath))
                {
                    var fileProvider = new PhysicalFileProvider(webRootPath);
                    app.UseDefaultFiles(new DefaultFilesOptions
                    {
                        FileProvider = fileProvider
                    });
                    app.UseStaticFiles(new StaticFileOptions
                    {
                        FileProvider = fileProvider
                    });
                }
            })
            .Build();

        await newHost.StartAsync(cancellationToken);
        host = newHost;
        logger.LogInformation($"WebChat 服务已启动，端口 {port}，网页根目录 {webRootPath}");
    }

    async Task HandleWebSocketAsync(HttpContext httpContext)
    {
        WebSocket ws = await httpContext.WebSockets.AcceptWebSocketAsync();
        string clientId = Guid.NewGuid().ToString("N");
        clients[clientId] = ws;
        logger.LogInformation($"WebSocket 客户端已连接：{clientId}");

        if (ClientConnected != null)
            await ClientConnected.Invoke(clientId);

        try
        {
            await ReceiveLoopAsync(ws, clientId);
        }
        catch (Exception e)
        {
            logger.LogWarning($"客户端 {clientId} 连接异常：{e.GetType().Name}: {e.Message}");
        }
        finally
        {
            clients.TryRemove(clientId, out _);
            logger.LogInformation($"WebSocket 客户端已断开：{clientId}");

            if (ClientDisconnected != null)
                await ClientDisconnected.Invoke(clientId);
        }
    }

    async Task ReceiveLoopAsync(WebSocket ws, string clientId)
    {
        byte[] buffer = new byte[4096];
        using MemoryStream stream = new();

        while (ws.State == WebSocketState.Open)
        {
            stream.SetLength(0);
            WebSocketReceiveResult result;
            do
            {
                result = await ws.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);

                if (result.MessageType == WebSocketMessageType.Close)
                {
                    await ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "", CancellationToken.None);
                    return;
                }

                stream.Write(buffer, 0, result.Count);
            }
            while (!result.EndOfMessage);

            if (result.MessageType != WebSocketMessageType.Text)
                continue;

            string text = Encoding.UTF8.GetString(stream.ToArray());

            if (TextReceived != null)
                await TextReceived.Invoke(clientId, text);
        }
    }

    /// <summary>向所有在线客户端广播一条消息。</summary>
    public Task BroadcastAsync(ServerMessage message, CancellationToken cancellationToken = default)
    {
        string json = JsonSerializer.Serialize(message);
        return BroadcastRawAsync(json, cancellationToken);
    }

    /// <summary>向所有在线客户端广播一段原始文本（应当是协议约定的 JSON）。</summary>
    public async Task BroadcastRawAsync(string raw, CancellationToken cancellationToken = default)
    {
        byte[] data = Encoding.UTF8.GetBytes(raw);
        var segment = new ArraySegment<byte>(data);

        foreach (var pair in clients)
        {
            WebSocket ws = pair.Value;
            if (ws.State != WebSocketState.Open)
                continue;

            try
            {
                await ws.SendAsync(segment, WebSocketMessageType.Text, true, cancellationToken);
            }
            catch (Exception e)
            {
                logger.LogWarning($"向客户端 {pair.Key} 发送失败：{e.Message}");
            }
        }
    }

    public async ValueTask DisposeAsync()
    {
        IWebHost? oldHost = host;
        host = null;

        foreach (var pair in clients)
        {
            try
            {
                if (pair.Value.State == WebSocketState.Open)
                    await pair.Value.CloseAsync(WebSocketCloseStatus.NormalClosure, "", CancellationToken.None);
            }
            catch { }
        }
        clients.Clear();

        if (oldHost != null)
        {
            try
            {
                await oldHost.StopAsync();
            }
            catch { }
            finally
            {
                oldHost.Dispose();
            }
        }
    }

    /// <summary>获取本机在局域网中的 IPv4 地址，取不到时回退到 127.0.0.1。</summary>
    public static string GetLocalIP()
    {
        try
        {
            foreach (IPAddress ip in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
            {
                if (ip.AddressFamily != AddressFamily.InterNetwork)
                    continue;

                string addr = ip.ToString();
                if (addr.StartsWith("192.168.") || addr.StartsWith("10."))
                    return addr;

                if (addr.StartsWith("172."))
                {
                    string[] parts = addr.Split('.');
                    if (parts.Length >= 2 && int.TryParse(parts[1], out int second) && second >= 16 && second <= 31)
                        return addr;
                }
            }

            foreach (IPAddress ip in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                    return ip.ToString();
        }
        catch { }

        return "127.0.0.1";
    }
}

using System.Text.Json.Serialization;

namespace Miru.Function.WebChat;

/// <summary>
/// 网页发给服务端的消息。
/// 使用 Type 字段区分消息种类，便于以后扩展（图片、表情、指令等）。
/// </summary>
public sealed class ClientMessage
{
    /// <summary>消息种类：chat（聊天）、ping（心跳）。</summary>
    [JsonPropertyName("type")]
    public string? Type { get; set; }

    /// <summary>消息正文。</summary>
    [JsonPropertyName("text")]
    public string? Text { get; set; }

    /// <summary>客户端标识，由网页生成并保存在本地。</summary>
    [JsonPropertyName("clientId")]
    public string? ClientId { get; set; }
}

/// <summary>
/// 服务端发给网页的消息。
/// </summary>
public sealed class ServerMessage
{
    /// <summary>消息种类：message（聊天）、pong（心跳回应）。</summary>
    [JsonPropertyName("type")]
    public string Type { get; set; } = "message";

    /// <summary>发送者角色：assistant（AI）。</summary>
    [JsonPropertyName("role")]
    public string? Role { get; set; }

    /// <summary>消息正文。</summary>
    [JsonPropertyName("text")]
    public string? Text { get; set; }

    /// <summary>消息时间（毫秒时间戳）。</summary>
    [JsonPropertyName("time")]
    public long? Time { get; set; }
}
